<?php
/**
 * Plugin Name: WooCommerce Shipping Zones (Custom)
 * Plugin URI: https://github.com/iSohaibKhan/WooCommerce-Custom-Shipping-Zones-Plugin
 * Author: Sohaib S. Khan
 * Author URI: https://isohaibkhan.github.io
 * Description: WooCommerce Shipping Zones Plugin for custom states and cities in United Arab Emirates
 * Version: 1.0.0
 * License: GPL2 or Later.
 * License URL: http://www.gnu.org/licenses/gpl-2.0.txt
 * text-domain: prefix-plugin-name
*/

add_filter( 'woocommerce_states', 'isk_custom_shipping_zones' );

function isk_custom_shipping_zones( $states ) {
    
    $states['AE'] = array(
        'AE001' => 'Dubai',    
        'AE002' => 'Abu Dhabi',    
        'AE003' => 'Sharjah',
        'AE004' => 'Al Ain',
        'AE005' => 'Ajman',
        'AE006' => 'Ras-Al-Khaimah',
        'AE007' => 'Fujairah',
        'AE008' => 'Umm Al Quwain',
        'AE009' => 'Khor Fakkan',
        'AE010' => 'Shaikh Zayed City',
        'AE011' => 'Dibba Al-Hisn',
        'AE012' => 'Kalba',
        'AE013' => 'Dibba Al-Fujairah',
        'AE014' => 'Hatta',
        'AE015' => 'Al Dhaid',
        'AE016' => 'Ghiyathi',
        'AE017' => 'Al Ruways Industrial City',
        'AE018' => 'Mina Jebel Ali',
        'AE019' => 'Masfut',
        'AE020' => 'Al Madam',
        'AE021' => 'Maleha',
        'AE022' => 'Al Jazirah Al Hamrah',
        'AE023' => 'Al Batayih',
        'AE024' => 'Huwaylat',
        'AE025' => 'Masafi',
    );
    
    return $states ;
}